// import 'package:flutter/material.dart';

// void main() => runApp(MyApp());

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     final title = 'Simple List';
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: title,
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text(title),
//         ),
//         body: ListView(
//           children: <Widget>[
//             ListTile(
//               leading: Icon(Icons.star),
//               title: Text('Map'),
//             ),
//             ListTile(
//               leading: Icon(Icons.photo_album),
//               title: Text('Album'),
//             ),
//             ListTile(
//               leading: Icon(Icons.phone),
//               title: Text('Phone'),
//             ),
//             ListTile(
//               leading: Icon(Icons.phone),
//               title: Text('Fax'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final title = 'Simple Form';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: title,
      home: Scaffold(
        appBar: AppBar(
          title: Text(title),
        ),
        body: ListView(
          children: <Widget>[
            ListTile(
              title: Text('Nama Anda:'),
            ),

            ListTile(
              leading: TextField(),
            ),
            
            ListTile(
              leading: FlatButton(
                color: Colors.blue,
                child: Text('Submit Data'),
                onPressed: () {},
              ),
            ),

          ],
        ),
      ),
    );
  }
}