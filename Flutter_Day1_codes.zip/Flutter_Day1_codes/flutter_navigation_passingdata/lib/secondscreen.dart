import 'package:flutter/material.dart';

class SecondScreen extends StatefulWidget {

  //Create an Object to receive the Passed Data from _TextFieldController
  final String value;
  //This is how it goes to Secondscreen using key value
  SecondScreen({Key key, this.value}) : super (key: key);

  @override
  _SecondScreenState createState() => new _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Screen 2"),
      ),
      body: Center(
        //Display The Object received
        child: new Text('${widget.value}'),
      ),
    );
  }
}




