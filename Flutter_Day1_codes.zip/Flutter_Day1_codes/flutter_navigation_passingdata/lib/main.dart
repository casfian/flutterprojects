import 'package:flutter/material.dart';
import 'firstscreen.dart';
import 'secondscreen.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Passing Data',
    home: FirstScreen(),
    //guna Routing
    routes: <String, WidgetBuilder> {
    '/screen1': (BuildContext context) => new FirstScreen(),
    '/screen2': (BuildContext context) => new SecondScreen(),
    //----end define route
  },

  ));
}



