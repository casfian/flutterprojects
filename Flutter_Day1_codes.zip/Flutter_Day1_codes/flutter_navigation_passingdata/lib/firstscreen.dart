import 'package:flutter/material.dart';
import 'secondscreen.dart';

class FirstScreen extends StatefulWidget {
  @override
  _FirstScreenState createState() => new _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  
  final _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Screen 1'),
      ),
      body: new ListView( 
        children: <Widget>[
          new ListTile(title: new TextField(controller: _textController,),),
          new ListTile(title: new RaisedButton(
            child: new Text("Next"),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder:(context) 
                => new SecondScreen(value: _textController.text)));
            }
          ),)
        ],
      )
    );
  }
}



