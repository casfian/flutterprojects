import 'package:flutter/material.dart';
import 'package:firebase_admob/firebase_admob.dart';
 
void main() => runApp(MyApp());
 
class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  
  static final MobileAdTargetingInfo targetingInfo = MobileAdTargetingInfo(
  keywords: <String>['games', 'malaysia', 'ecommerce'],
  contentUrl: 'https://flutter.io',
  childDirected: true, 
  testDevices: <String>[],
);

BannerAd myBanner = BannerAd(
  //Step1: under your Admob App, create an AdUnit
  //Step2: Copy the AdUintId and paste here
  adUnitId: BannerAd.testAdUnitId,
  //replace once you wanna go live,
  //adUnitId: "ca-app-pub-xxxxxxxxxxxxxxx/xxxxxxxxxx",
  size: AdSize.smartBanner,
  targetingInfo: targetingInfo,
  listener: (MobileAdEvent event) {
    print("BannerAd event:- $event");
  },
);

// InterstitialAd myInterstitial = InterstitialAd(
//   adUnitId: InterstitialAd.testAdUnitId,
//   //adUnitId: "ca-app-pub-xxxxxxxxxxxxxxx/xxxxxxxxxx",
//   targetingInfo: targetingInfo,
//   listener: (MobileAdEvent event) {
//     print("InterstitialAd event:- $event");
//   },
// );

 @override
 void initState() { 
   //For "ca-app-pub-xxxxxxxxxxxxxxxx~xxxxxxxxxx", you have to get your own
   //Step1: Signup with Admob, https://admob.google.com
   //Step2: Create yr Admob App
   //Step3: Copy the AppId and paste here
   FirebaseAdMob.instance.initialize(appId: "ca-app-pub-xxxxxxxxxxxxxxxx~xxxxxxxxxx"); 
    myBanner..load()..show();
   super.initState();
 }

 @override
  void dispose() {
    myBanner.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Admob Demo',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Flutter Admob Demo'),
        ),
        
        body: Center(
          child: Container(
            child: Text('Hello Admob'),
          ),
        ),
      ),
    );
  }
}