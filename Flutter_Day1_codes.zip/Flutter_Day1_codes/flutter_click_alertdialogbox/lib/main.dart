//normal import library
import 'package:flutter/material.dart';

//The main function
void main(){ runApp(new MaterialApp(
  home: new MyApp(),
));
}

//Create variable, an enum for the alertbox buttons
enum MyDialogueAction{
  yes,
  no,
  maybe
}
//The myApp needs to be stateful to content the data that
//we will key-in the textfield 
class MyApp extends StatefulWidget {
  @override
  MyAppState createState() => new MyAppState();
}

class MyAppState extends State<MyApp> {
  String _text = '';
//bila ada value dlm textfield, maka _text jadi value yg kita input
  void _onChange(String value) {
    setState((){
      _text = value;
    });
  }

  @override
  Widget build (BuildContext context){
    return new Scaffold(
      
      appBar: new AppBar(
        title: new Text('Alert Demo'),
      ),body: new Container(
        child: new Column(
          children: <Widget>[
            new TextField(onChanged: (String value){ _onChange(value);},),
            new RaisedButton(
              onPressed: (){_showAlert(_text);},
              child: new Text('Press me'),
            )
          ],
        ),
      ),
    );
  } 

//This function for After we click the Alertbox button, 
//it will print on the debug console. This is optional but good to have.
  void _dialogueResult(MyDialogueAction value){
    print('you selected $value');
    Navigator.pop(context);
  }

//the alertbox function
 void _showAlert(String value){
  showDialog(
    context: context,
    builder: (_) => new AlertDialog(
      title: new Text('Alert!'),
      content: new Text(value,
      style: new TextStyle(fontSize: 30.0),),
      actions: <Widget>[
        new FlatButton(onPressed: () {_dialogueResult(MyDialogueAction.yes);}, 
        child: new Text('yes')),
        new FlatButton(onPressed: () {_dialogueResult(MyDialogueAction.no);}, 
        child: new Text('no')),
        new FlatButton(onPressed: () {_dialogueResult(MyDialogueAction.maybe);}, 
        child: new Text('maybe')),
      ],
    )
  );
}

}