import 'package:flutter/material.dart';
import 'secondscreen.dart';

class FirstScreen extends StatefulWidget {
  @override
  _FirstScreenState createState() => new _FirstScreenState();
}

class _FirstScreenState extends State<FirstScreen> {
  
  //var _textController = new TextEditingController(); 
  final _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Screen 1'),
      ),
      body: new ListView( 
        children: <Widget>[
          new ListTile(title: new TextField(controller: _textController,),),
          new ListTile(title: new RaisedButton(
            child: new Text("Next"),
            onPressed: () {
              //do something when pressed

              // original kaedah just navigate
              // var navigator = Navigator;
              // navigator.of(context).push(route);

              // // Kaedah 1
              // var route = new MaterialPageRoute(builder: (BuildContext context) => 
              //  new SecondScreen(value: _textController.text),);
              
              //Kaedah 2
              Navigator.push(context, MaterialPageRoute(builder:(context) 
                => new SecondScreen(value: _textController.text)));
            }
          ),)
        ],
      )
      /*body: Center(
        child: RaisedButton(
          child: Text('Goto screen 2'),
          onPressed: () {
            //ke screen 2
            Navigator.of(context).pushNamed('/screen2');
            //----
          },
        ),
      ), */
    );
  }
}