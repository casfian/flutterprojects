import 'package:flutter/material.dart';
import 'firstscreen.dart';
import 'secondscreen.dart';
import 'thirdscreen.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Navigation Basics',
    home: FirstScreen(),
    //guna Routing
    routes: <String, WidgetBuilder> {
    '/screen1': (BuildContext context) => new FirstScreen(),
    '/screen2': (BuildContext context) => new SecondScreen(),
    '/screen3': (BuildContext context) => new ThirdScreen(),
    //----end define route
  },

  ));
}

