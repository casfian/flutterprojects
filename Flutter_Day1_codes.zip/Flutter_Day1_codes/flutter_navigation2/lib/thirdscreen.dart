import 'package:flutter/material.dart';

class ThirdScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Screen 3"),
      ),
      body: Center(
        child: RaisedButton(
          child: Text('Go back Screen 1'),
          onPressed: () {
            //Guna ne utk balik ke screen 1
            Navigator.of(context).pushNamedAndRemoveUntil('/screen1', 
            (Route<dynamic> route) => false);
            //----
          },
        ),
      ),
    );
  }
}
