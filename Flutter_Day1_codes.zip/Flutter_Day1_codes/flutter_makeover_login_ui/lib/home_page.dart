import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  static String tag = 'home-page';

  @override
  Widget build(BuildContext context) {

    //avatar image
    final avatarphoto = Hero(
      tag: 'hero',
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: CircleAvatar(
          radius: 72.0,
          backgroundColor: Colors.transparent,
          backgroundImage: AssetImage('assets/userphoto.png'),
        ),
      ),
    );

    final welcome = Padding(
      padding: EdgeInsets.fromLTRB(10, 100, 10, 20),
      child: Text(
        'Welcome Caspian',
        style: TextStyle(fontSize: 28.0, color: Colors.white),
      ),
    );

    final welcometext = Padding(
      padding: EdgeInsets.all(8.0),
      child: Text(
        'This is just a Demo. You can change this.',
        style: TextStyle(fontSize: 16.0, color: Colors.white),
      ),
    );

    final logoutButton = Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: RaisedButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        onPressed: () {
          Navigator.of(context).pop(); //suka aku nak logout balik
        },
        padding: EdgeInsets.all(12),
        color: Colors.purpleAccent,
        child: Text('Log Out', style: TextStyle(color: Colors.white)),
      ),
      //------ 
    );

    final body = Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.all(28.0),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Colors.purple,
          Colors.pinkAccent,
        ]),
      ),
      child: Column(
        children: <Widget>[
          avatarphoto, 
          welcome, 
          welcometext, 
          logoutButton
          ],
      ),
    );

    return Scaffold(
      body: body,
    );
  }
}
